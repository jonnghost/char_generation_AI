import jsonschema
import json
from typing import Dict, Any, Tuple
from src.constants import CHART_LIBRARIES

with open("src/vega-lite-schema-v5.json", "r", encoding="utf-8") as f:
    VEGA_LITE_SCHEMA = json.load(f)

def validate_schema(chart_schema: Dict[str, Any], chart_library: str) -> Tuple[bool, str]:
    """Validates the schema for Vega-Lite, Plotly, or ECharts and provides detailed error messages."""

    if chart_library == "Vega-Lite":
        try:
            jsonschema.validate(instance=chart_schema, schema=VEGA_LITE_SCHEMA)
            return True, ""
        except jsonschema.exceptions.ValidationError as e:
            return False, f"Validation error in Vega-Lite schema: {e.message} at path: {list(e.path)}"

    elif chart_library == "Plotly":
        if not isinstance(chart_schema, dict):
            print(f" Debugging Plotly Schema Error: {json.dumps(chart_schema, indent=2)}")
            return False, "Invalid Plotly schema: Expected a dictionary."

        if "data" not in chart_schema or "layout" not in chart_schema:
            print(f" Debugging Plotly Schema Error: {json.dumps(chart_schema, indent=2)}")
            return False, "Invalid Plotly schema: Missing required keys: 'data' or 'layout'."

        return True, ""

    elif chart_library == "ECharts":
        if not isinstance(chart_schema, dict):
            print(f" Debugging ECharts Schema Error: {json.dumps(chart_schema, indent=2)}")
            return False, "Invalid ECharts schema: Expected a dictionary."

        # 🔹 Ensure we are validating the actual "chart_schema" and not extra metadata.
        if "chart_schema" in chart_schema:
            chart_schema = chart_schema["chart_schema"]

        # 🔹 Check if "series" exists at any depth
        series_exists = "series" in chart_schema or any(
            "series" in v if isinstance(v, dict) else False for v in chart_schema.values()
        )

        if not series_exists:
            print(f" Debugging ECharts Schema Error: {json.dumps(chart_schema, indent=2)}")
            return False, "Invalid ECharts schema: Missing required key 'series'."

        return True, ""

    return False, f"Unsupported chart library: {chart_library}."




# def validate_schema(chart_schema: Dict[str, Any], chart_library: str) -> Tuple[bool, str]:
#     """Validates the schema for Vega-Lite, Plotly, or ECharts and provides detailed error messages."""
    
#     if chart_library == "Vega-Lite":
#         try:
#             jsonschema.validate(instance=chart_schema, schema=VEGA_LITE_SCHEMA)
#             return True, ""
#         except jsonschema.exceptions.ValidationError as e:
#             return False, f"Validation error in Vega-Lite schema: {e.message} at path: {list(e.path)}"

#     elif chart_library == "Plotly":
#         if not isinstance(chart_schema, dict):
#             print(f"❌ Debugging Plotly Schema Error: {json.dumps(chart_schema, indent=2)}")
#             return False, "Invalid Plotly schema: Expected a dictionary."

#         if "data" not in chart_schema or "layout" not in chart_schema:
#             print(f"❌ Debugging Plotly Schema Error: {json.dumps(chart_schema, indent=2)}")
#             return False, "Invalid Plotly schema: Missing required keys: 'data' or 'layout'."
        
#         return True, ""

#     elif chart_library == "ECharts":
#         if not isinstance(chart_schema, dict):
#             print(f"❌ Debugging ECharts Schema Error: {json.dumps(chart_schema, indent=2)}")
#             return False, "Invalid ECharts schema: Expected a dictionary."

#         missing_keys = [key for key in ["series", "xAxis", "yAxis"] if key not in chart_schema]
#         if missing_keys:
#             print(f"❌ Debugging ECharts Schema Error: {json.dumps(chart_schema, indent=2)}")
#             return False, f"Invalid ECharts schema: Missing required keys: {', '.join(missing_keys)}."

#         return True, ""

#     return False, f"Unsupported chart library: {chart_library}."


