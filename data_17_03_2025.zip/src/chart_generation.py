from src.openai_api import generate_chart_with_validation as generate_chart
from src.validation import validate_schema

def create_chart(query: str, data: dict, chart_type: str = "", chart_library: str = "Vega-Lite") -> dict:
    """Generates a chart schema using LLM and validates it."""
    chart_schema = generate_chart(query, data, chart_type, chart_library)

    valid, error_message = validate_schema(chart_schema, chart_library)

    if valid:
        return chart_schema
    else:
        print(f"Invalid {chart_library} schema: {error_message}")
        return {}


# # from src.openai_api import generate_chart
# from src.openai_api import generate_chart_with_validation as generate_chart
# from src.validation import validate_vega_schema

# def create_chart(query: str, data: dict, chart_type: str = "") -> dict:
#     """Generates a Vega-Lite chart schema using LLM and validates it."""
#     chart_schema = generate_chart(query, data, chart_type)
    
#     if validate_vega_schema(chart_schema):
#         return chart_schema
#     else:
#         return {}