import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv(dotenv_path=".env", override=True)

# OpenAI API Key
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Supported Chart Types
CHART_TYPES = ["", "bar", "line", "multi_line", "area", "pie", "stacked_bar", "grouped_bar"]

# Supported Chart Libraries
CHART_LIBRARIES = ["Vega-Lite", "Plotly", "ECharts"]




# import os
# from dotenv import load_dotenv

# # Load environment variables from .env file
# load_dotenv(dotenv_path=".env", override=True)

# # OpenAI API Key (Replace with your actual key or use environment variables)
# OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
# # Supported Chart Types
# CHART_TYPES = [
#     "", "bar", "line", "multi_line", "area", "pie", "stacked_bar", "grouped_bar"
# ]

# # Vega-Lite Schema File Path
# VEGA_LITE_SCHEMA_PATH = os.path.join(os.path.dirname(__file__), "utils", "vega-lite-schema-v5.json")

# # VEGA_LITE_SCHEMA_PATH = "utils/vega-lite-schema-v5.json"