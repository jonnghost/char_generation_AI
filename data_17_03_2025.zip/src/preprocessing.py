
import json
import pandas as pd
from typing import Dict, Any, Tuple

def preprocess_data(uploaded_file) -> Tuple[Dict[str, Any], pd.DataFrame, Dict[str, list]]:
    """Extracts sample data and column values from the uploaded JSON file."""
    
    # Load JSON data
    data = json.load(uploaded_file)

    # Ensure data is a dictionary, not a list
    if isinstance(data, list):
        # Convert list to dictionary format (assuming list contains row data)
        df = pd.DataFrame(data)
        data = {"data": data, "columns": list(df.columns)}
    else:
        df = pd.DataFrame(data.get("data", []), columns=data.get("columns", []))

    # Extract sample column values
    sample_column_values = {col: df[col].unique().tolist()[:5] for col in df.columns} if not df.empty else {}

    return data, df, sample_column_values

