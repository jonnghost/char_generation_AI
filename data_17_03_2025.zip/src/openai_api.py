import json
import openai
import jsonschema
from src.constants import OPENAI_API_KEY
from src.validation import validate_schema
from src.prompts import chart_generation_system_prompt, chart_adjustment_system_prompt

# Set OpenAI API Key
openai.api_key = OPENAI_API_KEY


def convert_none_to_null(obj):
    """Recursively converts Python None values to JSON null and fixes 'frame' issues."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            obj[k] = convert_none_to_null(v)
    elif isinstance(obj, list):
        obj = [convert_none_to_null(v) for v in obj]
    elif obj is None:
        return None  # JSON automatically converts this to null

    if isinstance(obj, dict) and "frame" in obj:
        if obj["frame"] == [None, None]:
            obj["frame"] = [None, None]  # JSON will convert to [null, null]

    return obj


def call_openai_api(system_prompt: str, user_prompt: str) -> dict:
    """Calls OpenAI API to generate a chart schema."""
    client = openai.Client(api_key=OPENAI_API_KEY)

    try:
        response = client.chat.completions.create(
            model="gpt-4-turbo",
            temperature=0.2,  # Low temperature for consistency
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            response_format={"type": "json_object"}
        )
        response_data = json.loads(response.choices[0].message.content)

        # Extract the generated chart schema
        chart_schema = response_data.get("chart_schema", {})
        chart_schema.pop("data", None)  # Remove inline data if present
        chart_schema = convert_none_to_null(chart_schema)

        return {
            "reasoning": response_data.get("reasoning", "No reasoning provided."),
            "chart_type": response_data.get("chart_type", ""),
            "chart_schema": chart_schema
        }

    except Exception as e:
        print(f"OpenAI API Error: {e}")
        return {"reasoning": "Error generating reasoning.", "chart_type": "", "chart_schema": {}}



def generate_chart_with_validation(query: str, data: dict, chart_type: str = "", chart_library: str = "Vega-Lite") -> dict:
    """Generates a chart schema with automatic validation, retry, and correction."""
    
    user_prompt = f"""
    ### INPUT ###
    Question: {query}
    Sample Data: {data.get('data', [])[:10]}
    Columns: {data.get('columns', [])}
    Preferred Chart Type: {chart_type}
    Chart Library: {chart_library}

    Ensure all column names match exactly.
    """

    max_attempts = 2  # Number of retry attempts
    attempt = 0

    while attempt < max_attempts:
        print(f"Attempt {attempt+1} - Generating {chart_library} Chart from LLM...")
        response = call_openai_api(chart_generation_system_prompt, user_prompt)

        # Extract explicitly
        reasoning = response.get("reasoning", "No reasoning provided.")
        chart_type = response.get("chart_type", "")
        chart_schema = response.get("chart_schema", {})

        chart_schema = convert_none_to_null(chart_schema)

        valid, error_message = validate_schema(chart_schema, chart_library)

        if valid:
            print(f"Valid {chart_library} schema generated!")
            print(f"Reasoning: {reasoning}")
            print(f"Chart Type: {chart_type}")
            return response

        else:
            print(f"Invalid {chart_library} schema detected! Asking LLM to correct it...")
            print(f"Error Details: {error_message}")

            # 🔹 Dynamically extract categories and time periods from the dataset
            categories = set()
            time_periods = set()
            category_column, time_column = None, None

            # Identify possible category and time columns dynamically
            if 'data' in data:
                for row in data['data']:
                    for col, value in row.items():
                        if isinstance(value, str):  # Possible categorical variable
                            categories.add(value)
                            if category_column is None:
                                category_column = col
                        elif isinstance(value, (int, float)) and time_column is None:  # Possible time variable
                            time_column = col

            categories = list(categories)
            time_periods = list(time_periods) if time_column else []

            correction_prompt = f""" 
            ### ERROR DETECTED ###
            The previous {chart_library} schema you generated is INVALID.

            ERROR DETAILS:
            {error_message}
            
            REQUIRED FIX:
            - **Ensure this is a true grouped bar chart** where each month has multiple bars (one for each product category).
            - **The "legend" must include all product categories, so users can identify them.**
            - **Each product category must have a corresponding "name" inside "series".**
            - **Ensure multiple bars appear for each month, grouped by category.**

            DATASET OVERVIEW:
            - **Detected Category Column:** {category_column if category_column else "None"}
            - **Detected Time Column:** {time_column if time_column else "None"}
            - **Available Categories:** {categories}
            - **Available Time Periods:** {time_periods}

            **For Plotly:**
            - Ensure "data" contains at least one trace with "type", "x", and "y".
            - Example:
                {{
                  "data": [
                    {{
                      "type": "{chart_type if chart_type else 'bar'}",
                      "x": {time_periods if time_periods else ["Category A", "Category B"]},
                      "y": [10, 15]
                    }}
                  ],
                  "layout": {{
                    "title": "{query}",
                    "xaxis": {{ "title": "{time_column if time_column else 'Categories'}" }},
                    "yaxis": {{ "title": "Value" }}
                  }}
                }}

            **For ECharts:**
            - Ensure the legend is included with all categories.
            - Each category should be mapped in "series" with a matching "name".

            - Example:
                {{
                    "legend": {{
                        "data": {categories}
                    }},
                    "xAxis": {{
                        "type": "category",
                        "data": {time_periods if time_periods else ["Month A", "Month B"]}
                    }},
                    "yAxis": {{
                        "type": "value"
                    }},
                    "series": [
                        {{
                        "name": "{categories[0] if categories else 'Category A'}",
                        "type": "bar",
                        "data": [10, 20, 30]
                        }},
                        {{
                        "name": "{categories[1] if len(categories) > 1 else 'Category B'}",
                        "type": "bar",
                        "data": [15, 25, 35]
                        }},
                        {{
                        "name": "{categories[2] if len(categories) > 2 else 'Category C'}",
                        "type": "bar",
                        "data": [5, 10, 15]
                        }}
                    ]
                }}


            **For Vega-Lite:**
            - Ensure the schema correctly defines encoding for the data.
            - Example:
                {{
                  "mark": "{chart_type if chart_type else 'bar'}",
                  "encoding": {{
                    "x": {{"field": "{time_column if time_column else 'category'}", "type": "ordinal"}},
                    "y": {{"field": "value", "type": "quantitative"}},
                    "color": {{"field": "{category_column if category_column else 'category'}", "type": "nominal"}}
                  }}
                }}
            """

            user_prompt += correction_prompt  # Append dynamically-generated error details for retry
            attempt += 1

    print(f" Maximum retries reached. Returning the last generated (invalid) {chart_library} schema.")
    return response  # Return last attempt even if invalid




def adjust_chart(chart_schema: dict, new_chart_type: str, x_axis: str, y_axis: str, chart_library: str) -> dict:
    """Adjusts an existing chart schema using OpenAI."""
    user_prompt = f"""
    ### INPUT ###
    Original {chart_library} Schema: {json.dumps(chart_schema)}
    Adjustments:
    - Chart Type: {new_chart_type}
    - X Axis: {x_axis}
    - Y Axis: {y_axis}
    
    Ensure all column names match exactly.
    """
    
    response = call_openai_api(chart_adjustment_system_prompt, user_prompt)
    
    # Validate adjusted schema explicitly
    chart_schema_adjusted = response.get("chart_schema", {})
    valid, error_message = validate_schema(chart_schema_adjusted, chart_library)

    if valid:
        print(f"Adjusted {chart_library} schema is valid.")
        return response
    else:
        print(f"Adjusted {chart_library} schema validation error: {error_message}")
        return {"reasoning": "Adjusted schema validation failed.", "chart_type": "", "chart_schema": {}}



# import json
# import openai
# import jsonschema
# from src.constants import OPENAI_API_KEY
# from src.validation import validate_vega_schema
# from src.prompts import chart_generation_system_prompt,chart_adjustment_system_prompt

# # Set OpenAI API Key
# openai.api_key = OPENAI_API_KEY


# def convert_none_to_null(obj):
#     """Recursively converts Python None values to JSON null and fixes 'frame' issues."""
#     if isinstance(obj, dict):
#         for k, v in obj.items():
#             obj[k] = convert_none_to_null(v)
#     elif isinstance(obj, list):
#         obj = [convert_none_to_null(v) for v in obj]
#     elif obj is None:
#         return None  # JSON automatically converts this to null

#     #Fix 'frame' issue: Convert [None, None] → [null, null]
#     if isinstance(obj, dict) and "frame" in obj:
#         if obj["frame"] == [None, None]:
#             obj["frame"] = [None, None]  # JSON will convert to [null, null]

#     return obj




# def call_openai_api(system_prompt: str, user_prompt: str) -> dict:
#     """Calls OpenAI API to generate a chart schema."""
#     client = openai.Client(api_key=OPENAI_API_KEY)

#     try:
#         response = client.chat.completions.create(
#             model="gpt-4-turbo",
#             temperature=0.2,  # low temp for consistent yet slightly creative schemas
#             messages=[
#                 {"role": "system", "content": system_prompt},
#                 {"role": "user", "content": user_prompt}
#             ],
#             response_format={"type": "json_object"}
#         )
#         response_data = json.loads(response.choices[0].message.content)

#         # Extract the generated chart schema
#         chart_schema = response_data.get("chart_schema", {})
#         chart_schema.pop("data", None)  # Remove inline data if present
#         chart_schema = convert_none_to_null(chart_schema)

#         return {
#             "reasoning": response_data.get("reasoning", "No reasoning provided."),
#             "chart_type": response_data.get("chart_type", ""),
#             "chart_schema": chart_schema
#         }

#     except Exception as e:
#         print(f" OpenAI API Error: {e}")
#         return {"reasoning": "Error generating reasoning.", "chart_type": "", "chart_schema": {}}

# def generate_chart_with_validation(query: str, data: dict, chart_type: str = "") -> dict:
#     """Generates a Vega-Lite chart schema with automatic validation and retry."""
    
#     user_prompt = f"""
#     ### INPUT ###
#     Question: {query}
#     Sample Data: {data.get('data', [])[:10]}
#     Columns: {data.get('columns', [])}
#     Preferred Chart Type: {chart_type}

#     Ensure all column names match exactly.
#     """

#     max_attempts = 3  # Number of retry attempts
#     attempt = 0

#     while attempt < max_attempts:
#         print(f"Attempt {attempt+1} - Generating Chart from LLM...")
#         response = call_openai_api(chart_generation_system_prompt, user_prompt)

#         # Extract explicitly
#         reasoning = response.get("reasoning", "No reasoning provided.")
#         chart_type = response.get("chart_type", "")
#         chart_schema = response.get("chart_schema", {})

#         chart_schema = convert_none_to_null(chart_schema)

#         valid, error_message = validate_vega_schema(chart_schema)

#         if valid:
#             print("Valid Vega-Lite schema generated!")
#             print(f"Reasoning: {reasoning}")
#             print(f"Chart Type: {chart_type}")
#             return response

#         else:
#             print("Invalid schema detected! Asking LLM to correct it...")

#             # Create a correction prompt for the LLM
#             correction_prompt = f"""
#             ### ERROR DETECTED ###
#             The previous Vega-Lite schema you generated is INVALID according to Vega-Lite v5 standards.
#             Please correct the errors and regenerate a VALID schema.

#             ERROR DETAILS:
#             {error_message}
#             REQUIRED ACTION:
#             Please regenerate a VALID Vega-Lite schema. Carefully fix the issues above by strictly following:
#             - Correct field names from the provided dataset columns.
#             - Correct encoding types based on actual data.
#             - Explicit sorting definition (e.g., {{"sort": {{"field": "field_name", "order": "descending"}}}}).
#             - Correct filter syntax: either predicate (e.g., {{"filter": {{"field": "field_name", "op": "lte", "value": value}}}}) or expression form ("datum.field_name <= value").
#             - When using window transforms (e.g., rank), explicitly define the frame strictly as:
#                 {{"frame": [null, null]}}

#             Important:
#             - DO NOT USE Python-style 'None'. Use JSON 'null' only.

#             Strictly adhere to these syntax guidelines. Regenerate now.

#             Please regenerate the chart schema correctly.
#             """

#             user_prompt += correction_prompt  # Append error details for retry
#             attempt += 1

#     print("Maximum retries reached. Returning the last generated (invalid) schema.")
#     return response  # Return last attempt even if invalid


# def adjust_chart(chart_schema: dict, new_chart_type: str, x_axis: str, y_axis: str) -> dict:
#     """Adjusts an existing Vega-Lite chart schema using OpenAI."""
#     user_prompt = f"""
#     ### INPUT ###
#     Original Vega-Lite Schema: {json.dumps(chart_schema)}
#     Adjustments:
#     - Chart Type: {new_chart_type}
#     - X Axis: {x_axis}
#     - Y Axis: {y_axis}
#     Ensure all column names match exactly.
#     """
#     response = call_openai_api(chart_adjustment_system_prompt, user_prompt)
#     # Validate adjusted schema explicitly
#     chart_schema_adjusted = response.get("chart_schema", {})
#     valid, error_message = validate_vega_schema(chart_schema_adjusted)

#     if valid:
#         print("Adjusted Vega-Lite schema is valid.")
#         return response
#     else:
#         print(f"Adjusted schema validation error: {error_message}")
#         # Optionally handle further corrections here
#         return {"reasoning": "Adjusted schema validation failed.", "chart_type": "", "chart_schema": {}}


