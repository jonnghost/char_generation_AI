from src.openai_api import adjust_chart
from src.validation import validate_schema

def modify_chart(chart_schema: dict, new_chart_type: str, x_axis: str, y_axis: str, chart_library: str) -> dict:
    """Modifies an existing chart schema dynamically using LLM and validates it."""
    adjusted_schema = adjust_chart(chart_schema, new_chart_type, x_axis, y_axis, chart_library)

    valid, error_message = validate_schema(adjusted_schema, chart_library)

    if valid:
        return adjusted_schema
    else:
        print(f"Invalid {chart_library} schema: {error_message}")
        return {}


# from utils.openai_api import adjust_chart
# from utils.validation import validate_vega_schema

# def modify_chart(chart_schema: dict, new_chart_type: str, x_axis: str, y_axis: str) -> dict:
#     """Modifies an existing Vega-Lite chart schema dynamically using LLM and validates it."""
#     adjusted_schema = adjust_chart(chart_schema, new_chart_type, x_axis, y_axis)
    
#     if validate_vega_schema(adjusted_schema):
#         return adjusted_schema
#     else:
#         return {}