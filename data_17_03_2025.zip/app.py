import streamlit as st
import json
import pandas as pd
import altair as alt
import plotly.graph_objects as go
from streamlit_echarts import st_echarts
from src.openai_api import adjust_chart, generate_chart_with_validation
from src.preprocessing import preprocess_data
from src.validation import validate_schema
from src.constants import CHART_TYPES, CHART_LIBRARIES

# Streamlit UI Header
st.title("📊 AI-Powered Chart Generator & Adjuster")
st.write("Upload your dataset, ask a question, and get an interactive chart generated using OpenAI!")

# File Upload Section
uploaded_file = st.file_uploader("Upload JSON file", type=["json"])

data, df, sample_column_values = None, None, None
if uploaded_file:
    data, df, sample_column_values = preprocess_data(uploaded_file)
    st.subheader("Data Preview")
    st.write(df.head())

# User Query Input
query = st.text_input("Enter your question about the data:", placeholder="e.g., Show sales trends by region")
chart_type = st.selectbox("Select Chart Type (Optional)", CHART_TYPES)
chart_library = st.selectbox("Select Chart Library", CHART_LIBRARIES)

generated_chart = None
if st.button("Generate Chart") and query and df is not None:
    chart_schema = generate_chart_with_validation(query, data, chart_type, chart_library)

    valid, error_message = validate_schema(chart_schema, chart_library)

    if valid:
        st.subheader(f"Generated {chart_library} Chart")

        #  Ensure correct schema extraction
        if "chart_schema" in chart_schema:
            chart_schema = chart_schema["chart_schema"]

        if chart_library == "Vega-Lite":
            chart_schema["data"] = {"values": df.to_dict(orient="records")}
            try:
                chart = alt.Chart.from_json(json.dumps(chart_schema))
                st.altair_chart(chart, use_container_width=True)
            except Exception as e:
                st.error(f"Error rendering Vega-Lite chart: {str(e)}")

        elif chart_library == "Plotly":
            try:
                # 🔹 Fix Plotly schema issue
                fig = go.Figure(data=chart_schema.get("data", []))  
                fig.update_layout(chart_schema.get("layout", {}))
                st.plotly_chart(fig)
            except Exception as e:
                st.error(f"Error rendering Plotly chart: {str(e)}")

        elif chart_library == "ECharts":
            try:
                # 🔹 Fix ECharts schema issue
                st_echarts(options=chart_schema, height="500px")
            except Exception as e:
                st.error(f"Error rendering ECharts visualization: {str(e)}")

        #  Allow users to download the JSON schema
        st.download_button(
            f"Download {chart_library} JSON", 
            json.dumps(chart_schema, indent=2), 
            f"{chart_library.lower()}_chart.json", 
            "application/json"
        )

    else:
        st.error(f"Invalid {chart_library} schema: {error_message}")


# import streamlit as st
# import json
# import pandas as pd
# import altair as alt
# import plotly.graph_objects as go
# from streamlit_echarts import st_echarts
# from src.openai_api import adjust_chart, generate_chart_with_validation
# from src.preprocessing import preprocess_data
# from src.validation import validate_schema
# from src.constants import CHART_TYPES, CHART_LIBRARIES

# # Streamlit UI Header
# st.title("📊 AI-Powered Chart Generator & Adjuster")
# st.write("Upload your dataset, ask a question, and get an interactive chart generated using OpenAI!")

# # File Upload Section
# uploaded_file = st.file_uploader("Upload JSON file", type=["json"])

# data, df, sample_column_values = None, None, None
# if uploaded_file:
#     data, df, sample_column_values = preprocess_data(uploaded_file)
#     st.subheader("Data Preview")
#     st.write(df.head())

# # User Query Input
# query = st.text_input("Enter your question about the data:", placeholder="e.g., Show sales trends by region")
# chart_type = st.selectbox("Select Chart Type (Optional)", CHART_TYPES)
# chart_library = st.selectbox("Select Chart Library", CHART_LIBRARIES)

# generated_chart = None
# if st.button("Generate Chart") and query and df is not None:
#     chart_schema = generate_chart_with_validation(query, data, chart_type, chart_library)

#     valid, error_message = validate_schema(chart_schema, chart_library)

#     if valid:
#         st.subheader(f"Generated {chart_library} Chart")

#         if chart_library == "Vega-Lite":
#             chart_schema["data"] = {"values": df.to_dict(orient="records")}
#             chart = alt.Chart.from_json(json.dumps(chart_schema))
#             st.altair_chart(chart, use_container_width=True)

#         elif chart_library == "Plotly":
#             try:
#                 fig = go.Figure(chart_schema["data"])
#                 fig.update_layout(chart_schema.get("layout", {}))
#                 st.plotly_chart(fig)
#             except Exception as e:
#                 st.error(f"Error rendering Plotly chart: {str(e)}")

#         elif chart_library == "ECharts":
#             try:
#                 st_echarts(options=chart_schema, height="500px")
#             except Exception as e:
#                 st.error(f"Error rendering ECharts visualization: {str(e)}")

#         st.download_button(
#             f"Download {chart_library} JSON", 
#             json.dumps(chart_schema, indent=2), 
#             f"{chart_library.lower()}_chart.json", 
#             "application/json"
#         )

#     else:
#         st.error(f"Invalid {chart_library} schema: {error_message}")




